<#
    // Default PDF Settings
    let memoryLimit = "128M",
        timeLimit = 120,
        extName = "DOMPDF",
        ext = GetExtensionObject(extName);
    if (ext.Enabled && ext.PROJ) {
        let memoryLimitWrk = ext.PROJ.MemoryLimit;
        if (!IsEmpty(memoryLimitWrk))
            memoryLimit = memoryLimitWrk;
        let timeLimitWrk = ext.PROJ.TimeLimit;
        if (!IsEmpty(timeLimitWrk))
            timeLimit = timeLimitWrk;
    }
#>
// Dompdf
$CONFIG["PDF_STYLESHEET_FILENAME"] = "<#= FolderPath("_css", true) + GetFileName("exportpdfcss", "", false).replace(/\.scss$/, ".css") #>"; // Export PDF CSS styles
$CONFIG["PDF_MEMORY_LIMIT"] = "<#= memoryLimit #>"; // Memory limit
$CONFIG["PDF_TIME_LIMIT"] = <#= timeLimit #>; // Time limit
$CONFIG["PDF_MAX_IMAGE_WIDTH"] = 650; // Make sure image width not larger than page width or "infinite table loop" error
$CONFIG["PDF_MAX_IMAGE_HEIGHT"] = 900; // Make sure image height not larger than page height or "infinite table loop" error
$CONFIG["PDF_IMAGE_SCALE_FACTOR"] = 1.53; // Scale factor
