<#
    // Default PDF Settings
    pdfPageBreakRecordCount = 0;
    pdfPageOrientation = "portrait";
    pdfPageSize = "a4";

    let extName = "DOMPDF",
        ext = GetExtensionObject(extName);
    if (ext && ext.Enabled) {
        let extTable = GetExtensionTable(extName, TABLE.TblName);
        if (extTable) {
            pdfPageBreakRecordCount = extTable.PageBreakRecordCount;
            pdfPageOrientation = extTable.PageOrientation;
            pdfPageSize = extTable.PageSize;
            if (exportPdf) {
                if (CONTROL.CtrlID == "view") {
                    if (!IsEmpty(extTable.ExportView)) {
                        exportPdf = extTable.ExportView;
                    }
                } else {
                    if (!IsEmpty(extTable.ExportList)) {
                        exportPdf = extTable.ExportList;
                    }
                }
            }
        }
    }
#>
