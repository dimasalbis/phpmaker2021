/*
 * *** -----------------------------------------
 * ***  IMPORTANT - DO NOT CHANGE
 * ***
 */

global.UseTCPDF = () => PdfBackend() == "TCPDF";

global.PdfBackend = () => {
    let pdfBackend = "TCPDF", // Default
        extName = "DOMPDF",
        ext = GetExtensionObject(extName);
    if (ext.Enabled && ext.PROJ) {
        let pdfBackendWrk = ext.PROJ.PdfBackend;
        if (!IsEmpty(pdfBackendWrk))
            pdfBackend = pdfBackendWrk;
    }
    let pdfFont = PdfFont();
    if (["Courier", "Helvetica", "Times", "DejaVuSans", "DejaVuSansMono", "DejaVuSerif"].includes(pdfFont)) { // Core font
        if (pdfBackend == "TCPDF")
            pdfBackend = "CPDF";
    } else { // Unicode font
        if (pdfBackend == "CPDF")
            pdfBackend = "TCPDF";
    }
    return pdfBackend;
}

global.PdfFont = () => {
    let pdfFont = "DejaVuSerif", // default
        extName = "DOMPDF",
        ext = GetExtensionObject(extName);
    if (ext.Enabled && ext.PROJ) {
        let pdfFontWrk = ext.PROJ.PdfFont;
        if (!IsEmpty(pdfFontWrk))
            pdfFont = pdfFontWrk;
    }
    let charSet = PROJ.CharSet ? PROJ.CharSet.toLowerCase() : "";
    if (charSet == "utf-8" && ["Courier", "Helvetica", "Times"].includes(pdfFont))
        pdfFont = "DejaVuSerif";
    return pdfFont;
}

global.PdfBgColor = (c) => (IsEmpty(c) || c.startsWith("$")) ? "inherit" : c;

global.PdfBorderColor = (c) => (IsEmpty(c) || c.startsWith("$")) ? "inherit" : c;

global.PdfColor = (c) => (IsEmpty(c) || c.startsWith("$")) ? "inherit" : c;

/*
 * ***
 * ***  IMPORTANT - DO NOT CHANGE
 * *** -----------------------------------------
 */
