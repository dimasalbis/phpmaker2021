// Check if use CKeditor
let useCKeditor = DB.Tables.some(t => t.Fields.some(f => f.FldUseDHTMLEditor));
global.UseCKeditor = () => useCKeditor;