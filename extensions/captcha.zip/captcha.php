<## Common config #>
<#= include('shared/config-common.php') #>

<## Page class begin #>
<#= include('shared/page-class-begin.php') #>

    /**
    * Page run
    *
    * @return void
    */
    public function run()
    {
        // Captcha
        $sessionName = Captcha()->getSessionName();
        $_SESSION[$sessionName] = Captcha()->show();

        // No need for view
        $this->terminate();
        return;
    }

<## Page class end #>
<#= include('shared/page-class-end.php') #>
