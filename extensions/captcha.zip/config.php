$CaptchaClass = "PhpCaptcha"; // Override default CAPTCHA class
