<#
    global.controllerActions.set("captcha", "[/{page}]"); // Add captcha action
#>