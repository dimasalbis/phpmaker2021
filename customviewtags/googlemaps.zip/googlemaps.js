global.googlemaps = {

    Name: 'googlemaps',
    CustomViewTemplate: function(o, tbl, fld, ctrl) {

        let table = tbl || TABLE, field = fld || FIELD, control = ctrl || CONTROL,
            tblVar = table.TblVar, ctrlId = control.CtrlID.toLowerCase();

        function getJsonValue(o, f, type) {
            let fld = o[f + "_field"];
            if (fld) {
                let wrkFld = GetFieldObject(table, fld);
                if (wrkFld) {
                    let fldObj = Code.fldObj(wrkFld),
                        cv = Code.getName(fldObj, Code.Field.CurrentValue),
                        val = Code.write(Code.toJson(cv, `"${type}"`));
                    return `${f}: ${val},\n`;
                }
            }
            return "";
        }

        let divId = field.FldVar, templateId = CustomScriptId(tblVar + "_" + field.FldParm, "oldvalue"), useSingleMap = false, useMarkerClusterer = false;
        if (["list", "grid", "delete", "preview", "summary"].includes(ctrlId)) {
            let rowcnt = ctrlId == "summary" ? CustomScriptGroupIndex(field, groupFields.length) : CustomScriptRowCnt();
            useSingleMap = IsBoolean(o["use_single_map"]) ? o["use_single_map"] : false;
            if (!useSingleMap)
                divId = divId.substr(0, 1) + rowcnt + divId.substr(1);
            templateId = CustomScriptId(tblVar + "_" + field.FldParm, "oldvalue", rowcnt);
            useMarkerClusterer = useSingleMap && (IsBoolean(o["use_marker_clusterer"]) ? o["use_marker_clusterer"] : false);
        }
        divId = "gm_" + tblVar + "_" + divId;
        let width = o["width"] || 200, height = o["height"] || 200, // Default 200 x 200
            singleMapWidth = o["single_map_width"] || 400, singleMapHeight = o["single_map_height"] || 400; // Default 400 x 400
        let obj = Object.assign({}, o, {
            id: divId,
            template_id: templateId,
            width: width,
            height: height,
            use_single_map: useSingleMap,
            use_marker_clusterer: useMarkerClusterer,
            single_map_width: singleMapWidth,
            single_map_height: singleMapHeight,
            geocoding_delay: IsNumber(o["geocoding_delay"]) ? o["geocoding_delay"] : 250, // Note: Change 250 to a larger number if encountering OVER_QUERY_LIMIT error.
            show_map_on_top: IsBoolean(o["show_map_on_top"]) ? o["show_map_on_top"] : true,
            show_all_markers: IsBoolean(o["show_all_markers"]) ? o["show_all_markers"] : true,
        });
        delete(obj.apikey);
        let wrk = getJsonValue(o, "latitude", "number") +
            getJsonValue(o, "longitude", "number") +
            getJsonValue(o, "address", "string") +
            getJsonValue(o, "type", "string") +
            getJsonValue(o, "zoom", "number") +
            getJsonValue(o, "title", "string") +
            getJsonValue(o, "icon", "string") +
            getJsonValue(o, "description", "string");

        let div = useSingleMap ? "" : `<div id="${divId}" class="ew-google-map" style="width: ${width}px; height: ${height}px;"></div>`;
        return `${div}{{{old_tag}}}
<script>
loadjs.ready("head", function() {
    ew.googleMaps.push(jQuery.extend(${JSON.stringify(obj)}, {
        ${wrk.replace(/,\n/, ",\n        ")}
    }));
});
</script>
`;
    }

}

global.GoogleMapsApiKey = "";

// Get Google Maps API Key
for (let t of TABLES) {
    if (t.TblGen) {
        for (let f of t.Fields) {
            if (f.FldGenerate && !IsEmpty(f.FldViewTemplate)) {
                let viewTemplate = f.FldViewTemplate.trim();
                let obj = ParseJson(viewTemplate);
                if (obj && SameText(obj.id, "googlemaps") && obj.apikey) {
                    GoogleMapsApiKey = obj.apikey;
                    break;
                }
            }
        }
        if (GoogleMapsApiKey)
            break;
    }
}

if (!GoogleMapsApiKey) {
    console.log("Error: Missing Google API Key! To use the Google Maps JavaScript API, " +
        "you must register your app project on the Google Cloud Platform Console and get a Google API key which you can add to your app first. " +
        "Read: https://developers.google.com/maps/documentation/javascript/get-api-key for details.");
}