ew.youTubeVideos = [];

function onYouTubeIframeAPIReady() {
    var $ = jQuery;
    $(function() {
        $.each(ew.youTubeVideos, function(i, video) {
            if (video && video["player"])
                return true; // Continue
            video["player"] = new YT.Player(video["id"], {
                height: video["height"],
                width: video["width"],
                videoId: video["videoid"],
                events: {
                    "onReady": function(evt) {
                        if (video["autoplay"])
                            evt.target.playVideo();
                    }
                }
            });
        });
    });
}

jQuery(function() {
    var $ = jQuery;
    $("#ew-modal-dialog").on("load.ew", onYouTubeIframeAPIReady);
    $(document).on("preview", onYouTubeIframeAPIReady);
});
