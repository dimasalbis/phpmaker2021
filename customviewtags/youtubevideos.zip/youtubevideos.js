global.youtubevideos = {

    Name: 'youtubevideos',
    CustomViewTemplate: function(o, tbl, fld, ctrl) {

        let table = tbl || TABLE,
            field = fld || FIELD,
            control = ctrl || CONTROL,
            ctrlId = control.CtrlID.toLowerCase();

        function getJSONValue(o, f, type) {
            let fld = o[f + "_field"];
            if (fld) {
                let wrkFld = GetFieldObject(table, fld);
                if (wrkFld) {
                    let fldObj = Code.fldObj(wrkFld),
                        cv = Code.getName(fldObj, Code.Field.CurrentValue),
                        val = Code.write(Code.toJson(cv, `"${type}"`));
                    return `    ${f}: ${val},\n`;
                }
            }
            return "";
        }

        let divId = field.FldVar;
        if (["list", "grid", "delete", "report", "preview"].includes(ctrlId))
            divId = divId.substr(0, 1) + CustomScriptRowCnt() + divId.substr(1);
        divId = "utvd_" + divId;
        let width = o["width"] || 426,
            height = o["height"] || 240; // Default 426 x 240
        let obj = {
            id: divId,
            width: width,
            height: height,
            videoid: o["videoid"],
            autoplay: o["autoplay"]
        }
        let wrk = getJSONValue(o, "width") + getJSONValue(o, "height") +
            getJSONValue(o, "videoid", "string") +
            getJSONValue(o, "autoplay", "boolean");

        return `<div id="${divId}" class="ew-youtube-video"></div>
<script>
loadjs.ready("youtubevideos", function() {
    ew.youTubeVideos.push(jQuery.extend(${JSON.stringify(obj)}, {
    ${wrk.replace(/,\n$/, "\n")}
    }));
});
</script>
`;

    }

}