global.phpbarcode = {

    Name: "phpbarcode",

    // "key":"value" || "key_field":"field"
    _getJsonValue: function(o, tbl, tblvar, f, def) {
        let fld = o[f + "_field"] ? o[f + "_field"] : o[f], hasDef = !IsUndefined(def);
        if (fld) {
            let wrkFld = o[f + "_field"] ? GetFieldObject(tbl, fld) : "";
            if (wrkFld) {
                let fldObj = Code.fldObj(wrkFld);
                return Code.getName(fldObj, Code.Field.CurrentValue);
            } else if (IsNumber(fld) && hasDef && IsNumber(def)) { // Assume number
                return fld;
            } else if (IsBoolean(fld) && hasDef && IsBoolean(def)) { // Assume boolean
                return Code.bool(fld);
            } else {
                return "'" + SingleQuote(fld) + "'";
            }
        } else if (hasDef) {
            if (IsNumber(def))
                return def;
            else if (IsBoolean(def))
                return Code.bool(def);
            else
                return "'" + SingleQuote(def) + "'";
        }
        return "''";
    },

    CustomViewTemplate: function(o, tbl, fld, ctrl) {
        let table = tbl || TABLE, field = fld || FIELD, control = ctrl || CONTROL,
            tblVar = table.TblVar;
        let height = this._getJsonValue(o, table, tblVar, "height", 60),
            barcode = this._getJsonValue(o, table, tblVar, "barcode"),
            encode = this._getJsonValue(o, table, tblVar, "encode");
        return `<?= Barcode()->show(${barcode}, ${encode}, ${height}) ?>`;
    },

    CustomViewTemplateExport: function(o, tbl, fld, ctrl) {
        let table = tbl || TABLE, field = fld || FIELD;
        let height = this._getJsonValue(o, table, "this", "height", 60),
            barcode = this._getJsonValue(o, table, "this", "barcode"),
            encode = this._getJsonValue(o, table, "this", "encode");
        return `$this->${field.FldParm}->ExportHrefValue = Barcode()->getHrefValue(${barcode}, ${encode}, ${height});`;
    }

}
