<## Common config #>
<#= include('shared/config-common.php') #>

<## Page class begin #>
<#= include('shared/page-class-begin.php') #>

/**
 * Page run
 *
 * @return void
 */
public function run()
{
    // Write barcode
    Barcode()->write(Get("data"), Get("encode"), Get("height"), Get("color"));

    // No need for view
    $this->terminate();
}

<## Page class end #>
<#= include('shared/page-class-end.php') #>
