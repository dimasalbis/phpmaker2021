<#
    global.controllerActions.set("barcode", ""); // Add barcode action
#>