// Get barcode instance
function Barcode()
{
    global $Barcode;
    $Barcode = $Barcode ?? new PhpBarcode();
    $Barcode->UsePhpExcel = Config("USE_PHPEXCEL");
    $Barcode->UsePhpWord = Config("USE_PHPWORD");
    $Barcode->Path = GetUrl("<#= GetRouteUrl("barcode") #>");
    return $Barcode;
}
