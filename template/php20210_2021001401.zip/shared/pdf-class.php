<?php

namespace <#= ProjectNamespace #>;

/**
 * Class for export to PDF
 */
class ExportPdf extends ExportBase
{
    // Export
    public function export()
    {
        echo "Export PDF extension disabled.";
    }

}
