<?php
// Close recordset
if ($<#= pageObj #>->Recordset) {
    $<#= pageObj #>->Recordset->close();
}
?>
