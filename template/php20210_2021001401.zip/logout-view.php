<## Common config #>
<#= include('shared/config-common.php') #>

<## Namespace #>
<#= include('shared/namespace.php') #>

<## Page load #>
<#= include('shared/page-load.php') #>

<## Page unload #>
<#= include('shared/page-unload.php') #>
