// Global user functions
<#= GetClientScript("Global", "Global Code") #>