<?php

namespace <#= ProjectNamespace #>;

/**
 * Sub page class
 */
class SubPage
{
    public $Active = false;
    public $Visible = true; // If false, add class "d-none", for tabs/pills only
    public $Disabled = false; // If true, add class "disabled", for tabs/pills only
}
